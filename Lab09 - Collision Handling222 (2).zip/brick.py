import random

from pico2d import *

class Brick:

    image = None;

    def __init__(self):
        self.x, self.y = 400, 140
        self.speed = 20
        if self.image == None:
            self.image = load_image('brick180x40.png')

    def update(self, frame_time):
            self.x -= frame_time * self.speed
    def draw(self):
        self.image.draw(self.x, self.y)

    def get_bb(self):
        return self.x -80 , self.y+20  , self.x +90 , self.y +20

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

